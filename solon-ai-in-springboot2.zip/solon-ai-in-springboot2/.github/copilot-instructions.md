# Solon AI + SpringBoot 2 MCP Example - Copilot Instructions

## Architecture Overview

This is a **dual-container hybrid architecture** integrating Solon AI (lightweight framework) within SpringBoot 2:
- **Primary Container**: SpringBoot 2 (`HelloApp` + RestControllers) handles HTTP requests
- **Secondary Container**: Solon framework runs embedded for **MCP (Model Context Protocol)** server functionality
- **Bridge**: `McpServerConfig` initializes Solon with custom MCP endpoints, registered as Spring beans to access SpringBoot components

**Critical Pattern**: The Solon container must be started in `@PostConstruct` and stopped in `@PreDestroy` to synchronize with SpringBoot lifecycle.

## Three Main Modules

### 1. LLM Module (`src/main/java/webapp/llm/`)
**Purpose**: ChatModel integration with LLM providers (e.g., Ollama, OpenAI)

**Key Files**:
- `_Constants.java`: API endpoint & model config (requires user customization)
- `ChatConfig.java`: Bean registration for `ChatModel` with injected tools
- `ChatController.java`: HTTP endpoints for synchronous calls and SSE streaming
  - `/chat/call`: Blocking chat request
  - `/chat/stream`: Server-Sent Events (SSE) for real-time responses using `SseEmitter`
- `tool/CalculatorTools.java`, `WeatherTools.java`: Tool classes with `@ToolMapping` annotations
  - **Convention**: Use `@Component` if injecting Spring beans, `@ToolMapping` for method descriptions
  - Parameters require `@Param` annotations for reflection-based invocation

**Workflow**: `ChatModel.of(url).provider(...).model(...).defaultToolsAdd(toolInstance).build()` then `.prompt().call()` or `.stream()`

### 2. MCP Server Module (`src/main/java/webapp/mcpserver/`)
**Purpose**: Expose tools/resources/prompts via Model Context Protocol (both STREAMABLE and SSE channels)

**Key Architecture**:
```
McpServerConfig (SpringBoot @Configuration)
  ├─ Starts embedded Solon in @PostConstruct with isolated mcpserver.yml config
  ├─ Converts Spring @Service beans → MCP endpoints via @McpServerEndpoint annotation
  └─ Manual endpoint builder: McpServerEndpointProvider for programmatic setup
```

**Endpoint Registration**: Two patterns:
1. **Annotation-Based** (Recommended): Mark `@Service` class with `@McpServerEndpoint`, implements `IMcpServerEndpoint`
2. **Manual Builder** (Legacy): `McpServerEndpointProvider.builder()` + registration in Solon container

**Supported Channels**:
- `McpChannel.STREAMABLE`: Binary streaming protocol
- `McpChannel.SSE`: Server-Sent Events via `/mcp/{endpoint}/sse`

**Tool/Resource/Prompt Definitions**:
- `@ToolMapping`: Function callable by LLM; description auto-converted to JSON schema
- `@ResourceMapping(uri="...")`: Static resources with URI scheme (e.g., `config://`, `db://`)
- `@PromptMapping`: Returns `List<ChatMessage>` for system prompts

**Critical**: Enable `-parameters` compiler argument in `pom.xml` so `@Param` annotations work without explicit `name` attributes.

### 3. Test/Client Module (`src/test/java/client/`)
**Pattern**: Use `@SolonTest` to auto-start SpringBoot + embedded Solon; tests call MCP endpoints via `McpClientProvider`

**MCP Client Flow**:
```java
McpClientProvider.builder()
  .channel(McpChannel.STREAMABLE|SSE)
  .apiUrl("http://localhost:8080/mcp/demo1/sse")
  .build()
  .callToolAsText(toolName, argsMap)  // or getPrompt, readResource
```

**Integration**: Chain client-fetched tools into `ChatModel.defaultToolsAdd(mcpClientProvider)` for LLM → MCP calls.

## Build & Run

**Maven Command** (produces fat JAR with dependencies):
```bash
mvn clean package assembly:single
java -jar target/solon-ai-in-springboot2.jar
```

**Tests**: Run `McpClientTest` → auto-starts server on `http://localhost:8080`, executes tool calls, validates responses

## Configuration Customization

- **LLM Config**: Edit `_Constants.java` (api_url, model_name, provider type)
- **MCP Endpoints**: Define in `mcpserver/` directory; Solon scans with minimal scope
- **Auth**: Implement custom `Filter` in `McpServerAuth` (checks `user` param); applied to `/mcp/*` paths
- **Logging**: `src/main/resources/application.yml`

## Common Development Tasks

1. **Add New MCP Tool**: Create `@Service` implementing `IMcpServerEndpoint` with `@ToolMapping` methods; add to `McpServerConfig.springCom2Endpoint()`
2. **Switch LLM Provider**: Change `_Constants` (provider + model) and ensure local API endpoint is running
3. **Stream Response Client**: Use `SseEmitter` in controller; frontend consumes via EventSource API
4. **Disable LLM Module**: Delete `llm/` package if only using MCP (avoids startup errors from missing model config)

## Critical Compilation Note

**Requirement**: `<compilerArgument>-parameters</compilerArgument>` in `maven-compiler-plugin` config (already set in pom.xml). This preserves method parameter names for runtime reflection used by `@Param` annotation resolution.

---

**Testing Entry**: `McpClientTest` (with auth test case); handles server startup via `@SolonTest` annotation
