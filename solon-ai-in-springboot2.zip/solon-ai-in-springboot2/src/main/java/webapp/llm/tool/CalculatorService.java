package webapp.llm.tool;

import org.springframework.stereotype.Component;

/**
 * 示意一下
 * */
@Component
public class CalculatorService {
}
