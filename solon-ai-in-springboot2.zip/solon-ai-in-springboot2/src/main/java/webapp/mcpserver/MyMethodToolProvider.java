package webapp.mcpserver;

import java.util.Collection;

import org.noear.solon.ai.chat.tool.FunctionTool;
import org.noear.solon.ai.chat.tool.MethodToolProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MyMethodToolProvider extends MethodToolProvider {

    Logger log = LoggerFactory.getLogger(McpServerAuth.class);
    public MyMethodToolProvider(Object bean) {
        super(bean);
    }

    @Override
    public Collection<FunctionTool> getTools() {
        super.getTools().forEach(tool -> {
            log.info("Tool loaded: name={}, description={}", tool.name(), tool.description());
        });

        return super.getTools();      
    }
}