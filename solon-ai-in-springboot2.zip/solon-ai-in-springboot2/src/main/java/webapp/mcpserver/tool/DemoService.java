package webapp.mcpserver.tool;

import org.springframework.stereotype.Service;

@Service
public class DemoService {

}
