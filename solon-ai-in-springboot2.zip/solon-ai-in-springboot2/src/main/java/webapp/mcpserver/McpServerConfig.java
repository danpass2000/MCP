package webapp.mcpserver;

import org.noear.solon.Solon;
import org.noear.solon.ai.chat.tool.FunctionTool;
import org.noear.solon.ai.chat.tool.FunctionToolDesc;
import org.noear.solon.ai.chat.tool.MethodToolProvider;
import org.noear.solon.ai.mcp.McpChannel;
import org.noear.solon.ai.mcp.server.IMcpServerEndpoint;
import org.noear.solon.ai.mcp.server.McpServerEndpointProvider;
import org.noear.solon.ai.mcp.server.annotation.McpServerEndpoint;
import org.noear.solon.ai.mcp.server.prompt.MethodPromptProvider;
import org.noear.solon.ai.mcp.server.resource.MethodResourceProvider;
import org.noear.solon.web.servlet.SolonServletFilter;
import org.springframework.aop.support.AopUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.AnnotationUtils;

import webapp.llm.tool.CalculatorTools;
import webapp.mcpserver.tool.McpServerTool2;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import java.util.ArrayList;
import java.util.List;

/**
 * 这个类独立一个目录，可以让 Solon 扫描范围最小化
 * */
@Configuration
public class McpServerConfig {
    @Value("${server.servlet.context-path:}")
    private String contextPath;

    @Autowired
    private List<IMcpServerEndpoint> serverEndpoints;

    @PostConstruct
    public void start() {
        System.setProperty("server.contextPath", contextPath);

        Solon.start(McpServerConfig.class, new String[]{"--cfg=mcpserver.yml"}, app -> {
            //添加全局鉴权过滤器示例（如果不需要，可以删掉）
            app.enableScanning(false); //不扫描
            app.filter(new McpServerAuth());
        });

        /**
         * 手动构建端点示例（仅供参考）
         * */

        //手动构建 mcp 服务端点（只是演示，可以去掉）
        McpServerEndpointProvider endpointProvider = McpServerEndpointProvider.builder()
                .name("McpServerTool2")
                .channel(McpChannel.SSE)
                .sseEndpoint("/mcp/demo2/sse")
                .build();
        endpointProvider.addTool(new MethodToolProvider(new McpServerTool2()));
        endpointProvider.addTool(new MyMethodToolProvider(new CalculatorTools()));
        endpointProvider.addResource(new MethodResourceProvider(new McpServerTool2()));
        endpointProvider.addPrompt(new MethodPromptProvider(new McpServerTool2()));
        endpointProvider.postStart();

        //手动加入到 solon 容器（只是演示，可以去掉）
        Solon.context().wrapAndPut(endpointProvider.getName(), endpointProvider);

        buildSystemMcpEndpoint();

        /**
         * Spring 组件转为端点
         * */

        springCom2Endpoint();
    }

    @PreDestroy
    public void stop() {
        if (Solon.app() != null) {
            //停止 solon（根据配置，可支持两段式安全停止）
            Solon.stopBlock(false, Solon.cfg().stopDelay());
        }
    }

    //Spring 组件转为端点
    protected void springCom2Endpoint() {
        //提取实现容器里 IMcpServerEndpoint 接口的 bean ，并注册为服务端点
        for (IMcpServerEndpoint serverEndpoint : serverEndpoints) {
            Class<?> serverEndpointClz = AopUtils.getTargetClass(serverEndpoint);
            McpServerEndpoint anno = AnnotationUtils.findAnnotation(serverEndpointClz, McpServerEndpoint.class);

            if (anno == null) {
                continue;
            }

            McpServerEndpointProvider serverEndpointProvider = McpServerEndpointProvider.builder()
                    .from(serverEndpointClz, anno)
                    .build();

            serverEndpointProvider.addTool(new MethodToolProvider(serverEndpointClz, serverEndpoint));
            serverEndpointProvider.addResource(new MethodResourceProvider(serverEndpointClz, serverEndpoint));
            serverEndpointProvider.addPrompt(new MethodPromptProvider(serverEndpointClz, serverEndpoint));

            serverEndpointProvider.postStart();

            //可以再把 serverEndpointProvider 手动转入 SpringBoot 容器
        }
    }

    @Bean
    public FilterRegistrationBean mcpServerFilter() {
        //通过 Servlet Filter 实现 http 能力对接
        FilterRegistrationBean<SolonServletFilter> filter = new FilterRegistrationBean<>();
        filter.setName("SolonFilter");
        filter.addUrlPatterns("/mcp/*");
        filter.setFilter(new SolonServletFilter());
        return filter;
    }

    public void buildSystemMcpEndpoint() {

        List<SystemMcpEndpoint> systems = new ArrayList<>();
        SystemMcpEndpoint systemA = new SystemMcpEndpoint();
        systemA.sysName = "systemA";
        systemA.sysDesc = "system A description";
        systems.add(systemA);

        systemA.tools = new ArrayList<>();
        ToolEndpoint toolA1 = new ToolEndpoint();
        toolA1.toolName = "toolA1";
        toolA1.toolDesc = "tool A1 description";
        toolA1.url = "/mcp/systemA/toolA1";
        toolA1.inParam = "inputParamA1";
        toolA1.inParamDesc = "input parameter A1 description";
        toolA1.outParam = "outputParamA1";
        toolA1.outParamDesc = "output parameter A1 description";
        systemA.tools.add(toolA1);

        ToolEndpoint toolA2 = new ToolEndpoint();
        toolA2.toolName = "toolA2";
        toolA2.toolDesc = "tool A2 description";
        toolA2.url = "/mcp/systemA/toolA2";
        toolA2.inParam = "inputParamA2";
        toolA2.inParamDesc = "input parameter A2 description";
        toolA2.outParam = "outputParamA2";
        toolA2.outParamDesc = "output parameter A2 description";
        systemA.tools.add(toolA2);

        SystemMcpEndpoint systemB = new SystemMcpEndpoint();
        systemB.sysName = "systemB";
        systemB.sysDesc = "system B description";
        systems.add(systemB);

        systemB.tools = new ArrayList<>();
        ToolEndpoint toolB1 = new ToolEndpoint();
        toolB1.toolName = "toolB1";
        toolB1.toolDesc = "tool B1 description";
        toolB1.url = "/mcp/systemB/toolB1";
        toolB1.inParam = "inputParamA1";
        toolB1.inParamDesc = "input parameter B1 description";
        toolB1.outParam = "outputParamB1";
        toolB1.outParamDesc = "output parameter B1 description";
        systemB.tools.add(toolB1);

        ToolEndpoint toolB2 = new ToolEndpoint();
        toolB2.toolName = "toolB2";
        toolB2.toolDesc = "tool B2 description";
        toolB2.url = "/mcp/systemA/toolB2";
        toolB2.inParam = "inputParamA2";
        toolB2.inParamDesc = "input parameter B2 description";
        toolB2.outParam = "outputParamB2";
        toolB2.outParamDesc = "output parameter B2 description";
        systemB.tools.add(toolB2);

        for (SystemMcpEndpoint sys : systems) {
            //注册每个系统及其工具端点的逻辑
             McpServerEndpointProvider endpointProvider = McpServerEndpointProvider.builder()
                .name(sys.sysName)
                .channel(McpChannel.SSE)
                .sseEndpoint("/mcp/" + sys.sysName + "/sse")
                .build();

            for (ToolEndpoint tool : sys.tools) {
                endpointProvider.addTool( new FunctionToolDesc(tool.toolName)
                .description(tool.toolDesc)
                .stringParamAdd(tool.inParam, tool.inParamDesc)
                .doHandle(map -> {
                    return "Handled by " + tool.toolName;
                }));
            }            
            endpointProvider.postStart();
        }
    }       
}

class SystemMcpEndpoint {
    String sysName;
    String sysDesc;
    List<ToolEndpoint> tools;
}

class ToolEndpoint {
    String toolName;
    String toolDesc;
    String url;
    String inParam;
    String inParamDesc;
    String outParam;
    String outParamDesc;
}