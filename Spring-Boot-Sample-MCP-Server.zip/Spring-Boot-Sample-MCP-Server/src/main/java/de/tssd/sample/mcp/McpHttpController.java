package de.tssd.sample.mcp;

import org.springframework.http.MediaType;
import org.springframework.http.codec.ServerSentEvent;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Flux;

/**
 * Simple example controller that demonstrates accepting a streaming request
 * and returning a stream of server-sent events. Replace the echo logic
 * in `handleMessage` with integration to the MCP server handler when
 * available (for example, delegate to the Spring AI MCP WebFlux transport).
 */
//@RestController
//@RequestMapping("/mcp")
public class McpHttpController {

    @PostMapping(path = "/stream", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public Flux<ServerSentEvent<String>> stream(@RequestBody Flux<String> inbound) {
        return inbound.map(this::handleMessage)
                .map(payload -> ServerSentEvent.<String>builder()
                        .data(payload)
                        .build());
    }

    private String handleMessage(String incoming) {
        // TODO: Replace this echo implementation with real MCP processing.
        // Example integration point:
        //  - Parse incoming MCP JSON frame
        //  - Call MCP server handler / ToolCallbacks
        //  - Stream back partial responses as they become available

        // For now, return an echo so the endpoint demonstrates streaming.

        // return "echo: " + incoming;
        return incoming;
    }
}