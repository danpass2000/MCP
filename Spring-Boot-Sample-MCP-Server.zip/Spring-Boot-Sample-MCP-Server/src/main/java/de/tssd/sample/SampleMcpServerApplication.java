package de.tssd.sample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SampleMcpServerApplication {

    public static void main(String[] args) {
        // System.out.println("Starting Sample MCP Server Application...");
        SpringApplication.run(SampleMcpServerApplication.class, args);
    }
}
