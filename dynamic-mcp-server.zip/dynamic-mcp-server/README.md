# Dynamic MCP Server

動態 API Gateway 與 MCP 協議支援

## 快速開始

### 1. 啟動服務
```bash
# 啟動 Docker 服務
bash scripts/setup.sh

# 或手動啟動
docker-compose up -d
```

### 2. 編譯項目
```bash
mvn clean package
```

### 3. 運行應用
```bash
java -jar target/dynamic-mcp-server-1.0.0-SNAPSHOT.jar
```

### 4. 測試
訪問: http://localhost:8080/actuator/health

## 項目結構

- `src/main/java` - Java 源代碼
- `src/main/resources` - 配置文件
- `apisix/` - APISIX 配置
- `scripts/` - 實用腳本
- `mockserver/` - 模擬服務配置

## API 端點

- `GET /api/mcp/admin/apis` - 列出所有 API
- `POST /api/mcp/admin/apis` - 註冊新 API
- `PUT /api/mcp/admin/apis/{name}` - 更新 API
- `DELETE /api/mcp/admin/apis/{name}` - 刪除 API

## 配置

編輯 `src/main/resources/api-definitions.yml` 添加新的 API 定義。

## 授權

Apache License 2.0
