#!/bin/bash
echo "🚀 Starting Dynamic MCP Server..."
docker-compose up -d
echo "✅ Services started!"
echo "📊 Access points:"
echo "   - APISIX Gateway: http://localhost:9080"
echo "   - APISIX Admin: http://localhost:9180"
echo "   - MockServer: http://localhost:1080"
