package com.example.mcp.model;

import lombok.Data;
import java.util.List;
import java.util.Map;

@Data
class AuthConfig {
    private AuthType type;
    private String username;
    private String password;
    private String token;
    private String apiKey;
    private String headerName;
    
    public enum AuthType {
        NONE, BASIC, BEARER, API_KEY, CUSTOM
    }
}