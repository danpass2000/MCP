package com.example.mcp.model;

import lombok.Data;
import java.util.List;
import java.util.Map;

@Data
class ResponseMapping {
    private String dataPath; // JSONPath for extracting data
    private String errorPath;
    private Map<String, String> fieldMapping;
}