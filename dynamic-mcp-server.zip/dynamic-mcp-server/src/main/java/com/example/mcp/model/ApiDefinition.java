package com.example.mcp.model;

import lombok.Data;
import java.util.List;
import java.util.Map;

@Data
public class ApiDefinition {
    private String name;
    private String description;
    private String endpoint;
    private String method; // GET, POST, PUT, DELETE
    private ApiType type; // REST, SOAP, GRAPHQL
    private AuthConfig auth;
    private List<ParameterDefinition> parameters;
    private Map<String, String> headers;
    private ResponseMapping responseMapping;
    
    public enum ApiType {
        REST, SOAP, GRAPHQL
    }
}