package com.example.mcp.model;

import lombok.Data;
import java.util.List;
import java.util.Map;

@Data
class ParameterDefinition {
    private String name;
    private String type; // string, integer, boolean, object, array
    private boolean required;
    private String description;
    private Object defaultValue;
    private List<String> enumValues;
    private String location; // query, path, body, header
}