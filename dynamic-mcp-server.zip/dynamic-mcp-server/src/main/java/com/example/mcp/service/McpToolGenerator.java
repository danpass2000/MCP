package com.example.mcp.service;

import com.example.mcp.model.ApiDefinition;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.model.function.FunctionCallback;
import org.springframework.ai.model.function.FunctionCallbackWrapper;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.function.Function;

@Slf4j
@Service
@RequiredArgsConstructor
public class McpToolGenerator {
    
    private final DynamicApiExecutor apiExecutor;
    
    public FunctionCallback createToolFromApi(ApiDefinition apiDef) {
        log.info("Creating MCP tool for API: {}", apiDef.getName());
        
        // 創建動態函數
        Function<Map<String, Object>, String> function = parameters -> {
            log.info("Executing tool: {} with parameters: {}", apiDef.getName(), parameters);
            return apiExecutor.executeApi(apiDef, parameters);
        };
        
        // 構建 JSON Schema
        String jsonSchema = buildJsonSchema(apiDef);
        
        // 使用 FunctionCallbackWrapper 包裝
        return FunctionCallbackWrapper.builder(function)
            .withName(apiDef.getName())
            .withDescription(apiDef.getDescription())
            .withInputTypeSchema(jsonSchema)
            .build();
    }
    
    private String buildJsonSchema(ApiDefinition apiDef) {
        StringBuilder schema = new StringBuilder();
        schema.append("{");
        schema.append("\"type\": \"object\",");
        schema.append("\"properties\": {");
        
        boolean first = true;
        for (var param : apiDef.getParameters()) {
            if (!first) schema.append(",");
            first = false;
            
            schema.append("\"").append(param.getName()).append("\": {");
            schema.append("\"type\": \"").append(param.getType()).append("\",");
            schema.append("\"description\": \"").append(param.getDescription()).append("\"");
            
            if (param.getEnumValues() != null && !param.getEnumValues().isEmpty()) {
                schema.append(",\"enum\": [");
                schema.append(String.join(",", 
                    param.getEnumValues().stream()
                        .map(v -> "\"" + v + "\"")
                        .toList()));
                schema.append("]");
            }
            
            schema.append("}");
        }
        
        schema.append("},");
        schema.append("\"required\": [");
        schema.append(String.join(",", 
            apiDef.getParameters().stream()
                .filter(p -> p.isRequired())
                .map(p -> "\"" + p.getName() + "\"")
                .toList()));
        schema.append("]");
        schema.append("}");
        
        return schema.toString();
    }
}