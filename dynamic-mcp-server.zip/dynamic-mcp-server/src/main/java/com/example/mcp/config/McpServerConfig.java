package com.example.mcp.config;

import com.example.mcp.model.ApiDefinition;
import com.example.mcp.service.ApiRegistry;
import com.example.mcp.service.McpToolGenerator;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.model.function.FunctionCallback;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Slf4j
@Configuration
@RequiredArgsConstructor
public class McpServerConfig {
    
    private final ApiRegistry apiRegistry;
    private final McpToolGenerator toolGenerator;
    
    @Value("${apis.config.path}")
    private Resource apiConfigResource;
    
    /**
     * 啟動時自動載入並註冊 API 定義
     */
    @Bean
    public CommandLineRunner loadApiDefinitions() {
        return args -> {
            log.info("Loading API definitions from: {}", apiConfigResource);
            
            ObjectMapper yamlMapper = new ObjectMapper(new YAMLFactory());
            
            try (InputStream is = apiConfigResource.getInputStream()) {
                Map<String, Object> config = yamlMapper.readValue(is, Map.class);
                List<Map<String, Object>> apiList = (List<Map<String, Object>>) config.get("apis");
                
                for (Map<String, Object> apiMap : apiList) {
                    ApiDefinition apiDef = yamlMapper.convertValue(apiMap, ApiDefinition.class);
                    apiRegistry.registerApi(apiDef);
                    log.info("Loaded API definition: {}", apiDef.getName());
                }
                
                log.info("Successfully loaded {} API definitions", apiList.size());
            } catch (Exception e) {
                log.error("Failed to load API definitions", e);
                throw e;
            }
        };
    }
    
    /**
     * 註冊所有 API 為 MCP Tools
     */
    @Bean
    public List<FunctionCallback> mcpTools() {
        List<FunctionCallback> tools = new ArrayList<>();
        
        for (ApiDefinition apiDef : apiRegistry.getAllApis()) {
            FunctionCallback tool = toolGenerator.createToolFromApi(apiDef);
            tools.add(tool);
            log.info("Registered MCP tool: {}", apiDef.getName());
        }
        
        return tools;
    }
}