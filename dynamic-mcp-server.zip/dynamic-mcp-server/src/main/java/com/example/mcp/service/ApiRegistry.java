package com.example.mcp.service;

import com.example.mcp.model.ApiDefinition;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

@Slf4j
@Service
public class ApiRegistry {
    
    private final Map<String, ApiDefinition> registeredApis = new ConcurrentHashMap<>();
    
    public void registerApi(ApiDefinition apiDef) {
        registeredApis.put(apiDef.getName(), apiDef);
        log.info("Registered API: {}", apiDef.getName());
    }
    
    public void unregisterApi(String name) {
        registeredApis.remove(name);
        log.info("Unregistered API: {}", name);
    }
    
    public ApiDefinition getApi(String name) {
        return registeredApis.get(name);
    }
    
    public List<ApiDefinition> getAllApis() {
        return new ArrayList<>(registeredApis.values());
    }
    
    public boolean exists(String name) {
        return registeredApis.containsKey(name);
    }
}