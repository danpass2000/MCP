package com.example.mcp.controller;

import com.example.mcp.model.ApiDefinition;
import com.example.mcp.service.ApiRegistry;
import com.example.mcp.service.McpToolGenerator;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.model.function.FunctionCallback;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/api/mcp/admin")
@RequiredArgsConstructor
public class McpAdminController {
    
    private final ApiRegistry apiRegistry;
    private final McpToolGenerator toolGenerator;
    // 注意：需要注入 McpSyncServer 來動態添加工具
    // private final McpSyncServer mcpSyncServer;
    
    /**
     * 查詢所有已註冊的 API
     */
    @GetMapping("/apis")
    public ResponseEntity<List<ApiDefinition>> listApis() {
        return ResponseEntity.ok(apiRegistry.getAllApis());
    }
    
    /**
     * 註冊新的 API
     */
    @PostMapping("/apis")
    public ResponseEntity<String> registerApi(@RequestBody ApiDefinition apiDef) {
        try {
            // 檢查是否已存在
            if (apiRegistry.exists(apiDef.getName())) {
                return ResponseEntity.badRequest()
                    .body("API already exists: " + apiDef.getName());
            }
            
            // 註冊到 Registry
            apiRegistry.registerApi(apiDef);
            
            // 創建 MCP Tool
            FunctionCallback tool = toolGenerator.createToolFromApi(apiDef);
            
            // 動態添加到 MCP Server
            // mcpSyncServer.addTool(tool);
            // mcpSyncServer.notifyToolsListChanged();
            
            log.info("Successfully registered API as MCP tool: {}", apiDef.getName());
            return ResponseEntity.ok("API registered: " + apiDef.getName());
            
        } catch (Exception e) {
            log.error("Failed to register API", e);
            return ResponseEntity.internalServerError()
                .body("Failed to register: " + e.getMessage());
        }
    }
    
    /**
     * 移除已註冊的 API
     */
    @DeleteMapping("/apis/{name}")
    public ResponseEntity<String> unregisterApi(@PathVariable String name) {
        if (!apiRegistry.exists(name)) {
            return ResponseEntity.notFound().build();
        }
        
        apiRegistry.unregisterApi(name);
        // mcpSyncServer.removeTool(name);
        // mcpSyncServer.notifyToolsListChanged();
        
        log.info("Unregistered API: {}", name);
        return ResponseEntity.ok("API unregistered: " + name);
    }
    
    /**
     * 更新 API 定義
     */
    @PutMapping("/apis/{name}")
    public ResponseEntity<String> updateApi(
        @PathVariable String name,
        @RequestBody ApiDefinition apiDef) {
        
        if (!apiRegistry.exists(name)) {
            return ResponseEntity.notFound().build();
        }
        
        // 移除舊的
        apiRegistry.unregisterApi(name);
        // mcpSyncServer.removeTool(name);
        
        // 註冊新的
        apiDef.setName(name);
        apiRegistry.registerApi(apiDef);
        
        FunctionCallback tool = toolGenerator.createToolFromApi(apiDef);
        // mcpSyncServer.addTool(tool);
        // mcpSyncServer.notifyToolsListChanged();
        
        return ResponseEntity.ok("API updated: " + name);
    }
}