package com.example.mcp.service;

import com.example.mcp.model.*;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.Map;

@Slf4j
@Service
@RequiredArgsConstructor
public class DynamicApiExecutor {
    
    private final RestTemplate restTemplate;
    private final ObjectMapper objectMapper;
    
    public String executeApi(ApiDefinition apiDef, Map<String, Object> parameters) {
        try {
            switch (apiDef.getType()) {
                case REST:
                    return executeRestApi(apiDef, parameters);
                case SOAP:
                    return executeSoapApi(apiDef, parameters);
                case GRAPHQL:
                    return executeGraphQLApi(apiDef, parameters);
                default:
                    throw new IllegalArgumentException("Unsupported API type: " + apiDef.getType());
            }
        } catch (Exception e) {
            log.error("Failed to execute API: {}", apiDef.getName(), e);
            return createErrorResponse(e);
        }
    }
    
    private String executeRestApi(ApiDefinition apiDef, Map<String, Object> parameters) {
        // 構建 URL
        String url = buildUrl(apiDef, parameters);
        
        // 構建 Headers
        HttpHeaders headers = buildHeaders(apiDef);
        
        // 構建 Body
        Object body = buildBody(apiDef, parameters);
        
        HttpEntity<?> entity = new HttpEntity<>(body, headers);
        
        log.info("Executing REST API: {} {}", apiDef.getMethod(), url);
        
        ResponseEntity<String> response = restTemplate.exchange(
            url,
            HttpMethod.valueOf(apiDef.getMethod()),
            entity,
            String.class
        );
        
        return processResponse(response.getBody(), apiDef.getResponseMapping());
    }
    
    private String executeSoapApi(ApiDefinition apiDef, Map<String, Object> parameters) {
        // 構建 SOAP Envelope
        String soapEnvelope = buildSoapEnvelope(apiDef, parameters);
        
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.TEXT_XML);
        headers.set("SOAPAction", apiDef.getHeaders().getOrDefault("SOAPAction", ""));
        
        addAuthHeaders(headers, apiDef.getAuth());
        
        HttpEntity<String> entity = new HttpEntity<>(soapEnvelope, headers);
        
        log.info("Executing SOAP API: {}", apiDef.getEndpoint());
        
        ResponseEntity<String> response = restTemplate.exchange(
            apiDef.getEndpoint(),
            HttpMethod.POST,
            entity,
            String.class
        );
        
        return extractSoapResponse(response.getBody());
    }
    
    private String executeGraphQLApi(ApiDefinition apiDef, Map<String, Object> parameters) {
        // GraphQL 查詢構建
        Map<String, Object> graphqlRequest = Map.of(
            "query", parameters.get("query"),
            "variables", parameters.getOrDefault("variables", Map.of())
        );
        
        HttpHeaders headers = buildHeaders(apiDef);
        headers.setContentType(MediaType.APPLICATION_JSON);
        
        HttpEntity<Map<String, Object>> entity = new HttpEntity<>(graphqlRequest, headers);
        
        log.info("Executing GraphQL API: {}", apiDef.getEndpoint());
        
        ResponseEntity<String> response = restTemplate.exchange(
            apiDef.getEndpoint(),
            HttpMethod.POST,
            entity,
            String.class
        );
        
        return response.getBody();
    }
    
    private String buildUrl(ApiDefinition apiDef, Map<String, Object> parameters) {
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(apiDef.getEndpoint());
        
        // 處理 query parameters
        for (ParameterDefinition param : apiDef.getParameters()) {
            if ("query".equals(param.getLocation()) && parameters.containsKey(param.getName())) {
                builder.queryParam(param.getName(), parameters.get(param.getName()));
            }
        }
        
        // 處理 path parameters
        String url = builder.build().toUriString();
        for (ParameterDefinition param : apiDef.getParameters()) {
            if ("path".equals(param.getLocation()) && parameters.containsKey(param.getName())) {
                url = url.replace("{" + param.getName() + "}", 
                                String.valueOf(parameters.get(param.getName())));
            }
        }
        
        return url;
    }
    
    private HttpHeaders buildHeaders(ApiDefinition apiDef) {
        HttpHeaders headers = new HttpHeaders();
        
        // 添加自定義 headers
        if (apiDef.getHeaders() != null) {
            apiDef.getHeaders().forEach(headers::set);
        }
        
        // 添加認證
        addAuthHeaders(headers, apiDef.getAuth());
        
        return headers;
    }
    
    private void addAuthHeaders(HttpHeaders headers, AuthConfig auth) {
        if (auth == null || auth.getType() == AuthConfig.AuthType.NONE) {
            return;
        }
        
        switch (auth.getType()) {
            case BASIC:
                String credentials = auth.getUsername() + ":" + auth.getPassword();
                String encodedCredentials = Base64.getEncoder()
                    .encodeToString(credentials.getBytes());
                headers.set("Authorization", "Basic " + encodedCredentials);
                break;
            case BEARER:
                headers.setBearerAuth(auth.getToken());
                break;
            case API_KEY:
                headers.set(auth.getHeaderName(), auth.getApiKey());
                break;
        }
    }
    
    private Object buildBody(ApiDefinition apiDef, Map<String, Object> parameters) {
        Map<String, Object> body = new HashMap<>();
        
        for (ParameterDefinition param : apiDef.getParameters()) {
            if ("body".equals(param.getLocation()) && parameters.containsKey(param.getName())) {
                body.put(param.getName(), parameters.get(param.getName()));
            }
        }
        
        return body.isEmpty() ? null : body;
    }
    
    private String buildSoapEnvelope(ApiDefinition apiDef, Map<String, Object> parameters) {
        StringBuilder soap = new StringBuilder();
        soap.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
        soap.append("<soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">");
        soap.append("<soap:Body>");
        
        // 簡化的 SOAP body 構建，實際應根據 WSDL 生成
        soap.append("<").append(apiDef.getName()).append(">");
        parameters.forEach((key, value) -> {
            soap.append("<").append(key).append(">")
                .append(value)
                .append("</").append(key).append(">");
        });
        soap.append("</").append(apiDef.getName()).append(">");
        
        soap.append("</soap:Body>");
        soap.append("</soap:Envelope>");
        
        return soap.toString();
    }
    
    private String extractSoapResponse(String soapResponse) {
        // 簡化的 SOAP 響應提取，實際應使用 XML 解析器
        int bodyStart = soapResponse.indexOf("<soap:Body>");
        int bodyEnd = soapResponse.indexOf("</soap:Body>");
        if (bodyStart > 0 && bodyEnd > bodyStart) {
            return soapResponse.substring(bodyStart + 11, bodyEnd);
        }
        return soapResponse;
    }
    
    private String processResponse(String response, ResponseMapping mapping) {
        if (mapping == null || mapping.getDataPath() == null) {
            return response;
        }
        
        try {
            JsonNode jsonNode = objectMapper.readTree(response);
            // 實際應使用 JSONPath 庫進行提取
            return jsonNode.toString();
        } catch (Exception e) {
            return response;
        }
    }
    
    private String createErrorResponse(Exception e) {
        try {
            Map<String, Object> error = Map.of(
                "error", true,
                "message", e.getMessage(),
                "type", e.getClass().getSimpleName()
            );
            return objectMapper.writeValueAsString(error);
        } catch (Exception ex) {
            return "{\"error\": true, \"message\": \"" + e.getMessage() + "\"}";
        }
    }
}